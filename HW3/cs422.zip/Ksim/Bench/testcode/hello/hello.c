/*
 * $Id*
 *
 * The simplest test program :)
 *
 */
void main (void)
{
  printf ("hello, world!\n");
  exit (2);
}

